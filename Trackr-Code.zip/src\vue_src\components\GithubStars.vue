<template>
    <a style="text-decoration: none; color:black;"href="https://github.com/andrewmillercode/Autofill-Jobs" target="_blank">
    <div class="starBtn">
        <div class="starBtnL">
            <h3>Star</h3>
            <svg xmlns="http://www.w3.org/2000/svg" height="26px" viewBox="0 -960 960 960" width="26px"
                fill="rgba(0,0,0,0.5)">
                <path
                    d="m354-287 126-76 126 77-33-144 111-96-146-13-58-136-58 135-146 13 111 97-33 143Zm126-28.92-145.23 87.69q-6.39 3.15-11.85 2.54-5.46-.62-10.61-3.77-5.16-3.16-7.85-9.04-2.69-5.88-.46-12.73l38.62-164.39-127.77-110.84q-5.39-4.39-7.12-10.5-1.73-6.12.73-11.73 2.46-5.62 6.62-9.16 4.15-3.53 11.23-4.77l168.61-14.69L460.69-733q2.69-6.62 7.81-9.54 5.12-2.92 11.5-2.92t11.5 2.92q5.12 2.92 7.81 9.54l65.77 155.69 168.61 14.69q7.08 1.24 11.23 4.77 4.16 3.54 6.62 9.16 2.46 5.61.73 11.73-1.73 6.11-7.12 10.5L617.38-415.62 656-251.23q2.23 6.85-.46 12.73-2.69 5.88-7.85 9.04-5.15 3.15-10.61 3.77-5.46.61-11.85-2.54L480-315.92ZM480-470Z" />
            </svg>
        </div>
        <h2>{{ inputValue }}</h2>
    </div>
</a>

</template>

<script lang="ts">
import { ref } from 'vue';

export default {

    setup() {
        // Declare a reactive input value using Vue's ref
        const inputValue = ref('');

        const loadData = () => {
            // Add stability class to prevent shaking during fetch
            const element = document.querySelector('.starBtn');
            if (element) {
                element.classList.add('fetch-operation');
            }
            
            fetch("https://api.github.com/repos/andrewmillercode/Autofill-Jobs", {
                headers: {
                    "Content-Type": "application/json",
                },

            }).then(res => res.json()).then(res => {
                inputValue.value = res['stargazers_count'];
                // Remove stability class after fetch completes
                if (element) {
                    element.classList.remove('fetch-operation');
                }
            }).catch(() => {
                // Remove stability class even on error
                if (element) {
                    element.classList.remove('fetch-operation');
                }
            })
        };

        // Load data when the component is mounted
        loadData();

        return {
            inputValue,
        };
    },
};
</script>

<style scoped>
/* Anti-flicker protection for GithubStars */
.starBtn {
  transition: none !important;
  animation: none !important;
  transform: none !important;
}

.starBtnL {
  transition: none !important;
  animation: none !important;
  transform: none !important;
}

.starBtn * {
  transition: none !important;
  animation: none !important;
  transform: none !important;
}

.starBtn svg {
  transition: none !important;
  animation: none !important;
  transform: none !important;
}
</style>